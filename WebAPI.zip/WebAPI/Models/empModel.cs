﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EndProject.Models
{
    public class empModel
    {
        public int EmpCode { get; set; }
        public string Email { get; set; }
        public string EmpName { get; set; }

        public int DeptCode { get; set; }




    }
}
